

const EditTask = () => {
  return (
    <div>
      Edit taskmanager
    </div>
  )
}

export default EditTask
